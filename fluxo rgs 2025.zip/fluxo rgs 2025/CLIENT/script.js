document.addEventListener("DOMContentLoaded", carregarNomes);

function carregarNomes() {
    fetch("http://localhost:3000/nomes")
        .then(response => response.json())
        .then(data => {
            const tabela = document.getElementById("tabelaNomes");
            tabela.innerHTML = "";

            data.forEach(item => {
                const row = document.createElement("tr");

                row.innerHTML = `
                    <td>${item.nome}</td>
                    <td><input type="text" value="${item.assinatura || ''}" class="assinatura"></td>
                    <td><input type="date" value="${item.data || ''}" class="data"></td>
                    <td><button onclick="registrar('${item.nome}', this)">Registrar</button></td>
                `;

                tabela.appendChild(row);
            });
        })
        .catch(error => console.error("Erro ao carregar nomes:", error));
}

function registrar(nome, botao) {
    const row = botao.closest("tr");
    const assinatura = row.querySelector(".assinatura").value;
    const data = row.querySelector(".data").value;

    fetch("http://localhost:3000/registrar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, assinatura, data })
    })
    .then(response => response.json())
    .then(() => carregarNomes())
    .catch(error => console.error("Erro ao registrar:", error));
}

function buscarNome() {
    const termo = document.getElementById("searchInput").value.toLowerCase();
    const linhas = document.querySelectorAll("#tabelaNomes tr");

    linhas.forEach(linha => {
        const nome = linha.cells[0].textContent.toLowerCase();
        linha.style.display = nome.includes(termo) ? "" : "none";
    });
}

function adicionarNomes() {
    const input = document.getElementById("novoNome").value.trim();
    if (!input) return alert("Digite pelo menos um nome!");

    const nomesArray = input.split(",").map(nome => nome.trim()).filter(nome => nome !== "");

    fetch("http://localhost:3000/adicionar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nomes: nomesArray })
    })
    .then(response => response.json())
    .then(() => {
        document.getElementById("novoNome").value = "";
        carregarNomes();
    })
    .catch(error => console.error("Erro ao adicionar nomes:", error));
}


function abrirAba(aba) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });

    document.getElementById(aba).classList.add('active');
    document.querySelector(`button[onclick="abrirAba('${aba}')"]`).classList.add('active');
}
