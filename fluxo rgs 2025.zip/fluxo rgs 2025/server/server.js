const express = require("express");
const fs = require("fs");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, "data.json");

app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, "../CLIENT")));

// Função para ler e ordenar os nomes alfabeticamente
function lerNomesOrdenados(callback) {
    fs.readFile(DATA_FILE, "utf8", (err, data) => {
        if (err) return callback(err, null);
        let nomes = JSON.parse(data);
        nomes.sort((a, b) => a.nome.localeCompare(b.nome)); // Ordena os nomes alfabeticamente
        callback(null, nomes);
    });
}

// Rota para obter a lista de nomes ordenados
app.get("/nomes", (req, res) => {
    lerNomesOrdenados((err, nomes) => {
        if (err) return res.status(500).json({ error: "Erro ao ler o arquivo." });
        res.json(nomes);
    });
});

// Rota para registrar um nome (assinatura e data)
app.post("/registrar", (req, res) => {
    const { nome, assinatura, data } = req.body;

    fs.readFile(DATA_FILE, "utf8", (err, fileData) => {
        if (err) return res.status(500).json({ error: "Erro ao ler o arquivo." });

        let nomes = JSON.parse(fileData);
        let nomeIndex = nomes.findIndex(item => item.nome === nome);

        if (nomeIndex !== -1) {
            nomes[nomeIndex].assinatura = assinatura;
            nomes[nomeIndex].data = data;
        }

        fs.writeFile(DATA_FILE, JSON.stringify(nomes, null, 2), err => {
            if (err) return res.status(500).json({ error: "Erro ao salvar." });
            res.json({ success: true });
        });
    });
});

// Rota para adicionar vários nomes de uma vez
app.post("/adicionar", (req, res) => {
    const { nomes } = req.body;

    fs.readFile(DATA_FILE, "utf8", (err, fileData) => {
        if (err) return res.status(500).json({ error: "Erro ao ler o arquivo." });

        let lista = JSON.parse(fileData);

        nomes.forEach(nome => {
            if (!lista.some(item => item.nome === nome.trim())) {
                lista.push({ nome: nome.trim(), assinatura: "", data: "" });
            }
        });

        // Ordenar alfabeticamente antes de salvar
        lista.sort((a, b) => a.nome.localeCompare(b.nome));

        fs.writeFile(DATA_FILE, JSON.stringify(lista, null, 2), err => {
            if (err) return res.status(500).json({ error: "Erro ao salvar." });
            res.json({ success: true });
        });
    });
});

app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
